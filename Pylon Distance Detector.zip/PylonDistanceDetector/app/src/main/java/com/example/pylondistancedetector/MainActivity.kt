package com.example.pylondistancedetector
import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.slider.Slider
import org.opencv.android.BaseLoaderCallback
import org.opencv.android.CameraBridgeViewBase
import org.opencv.android.CameraBridgeViewBase.CvCameraViewFrame
import org.opencv.android.CameraBridgeViewBase.CvCameraViewListener2
import org.opencv.android.LoaderCallbackInterface
import org.opencv.android.OpenCVLoader
import org.opencv.core.*
import org.opencv.core.Core.*
import org.opencv.imgproc.Imgproc
import org.w3c.dom.Text
import java.lang.Integer.min
import java.util.*
import kotlin.math.*

class MainActivity : AppCompatActivity(), CvCameraViewListener2 {
    // UI Variables

    // Declare OpenCV based camera view base
    private var mOpenCvCameraView: CameraBridgeViewBase? = null

    // Camera size
    private var myWidth = 0
    private var myHeight = 0

    // Mat to store RGBA and Grayscale camera preview frame
    private var mRgba: Mat? = null
    private var mGray: Mat? = null
    private var mHsv : Mat? = null
    private val myROIColor = Scalar(0.0, 0.0, 0.0)
    private var trackingFlag = 1
    private var maskFlag = 1
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        // Request User Permission on Camera
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 1)
        }

        // OpenCV Loader and Avoid using OpenCV Manager
        if (!OpenCVLoader.initDebug()) {
            Log.e(this.javaClass.simpleName, "  OpenCVLoader.initDebug(), not working.")
        } else {
            Log.d(this.javaClass.simpleName, "  OpenCVLoader.initDebug(), working.")
        }

        // Set up OpenCV Camera View
        mOpenCvCameraView = findViewById(R.id.videoViewCamera)
        mOpenCvCameraView!!.setCameraIndex(0)
        mOpenCvCameraView!!.setCameraPermissionGranted()
        mOpenCvCameraView!!.setCvCameraViewListener(this)
        val maskButton = findViewById<Button>(R.id.maskButton)
        val startStopButton = findViewById<Button>(R.id.startStopButton)

        maskButton.setOnClickListener{
            if(maskFlag == -1){
                maskButton.text = "Image"
                maskFlag = 1
            }
            else {
                maskButton.text = "Mask"
                maskFlag = -1
            }
        }

        startStopButton.setOnClickListener{
            if(trackingFlag == -1){
                startStopButton.text = "STOP"
                trackingFlag = 1
            }
            else {
                startStopButton.text = "START"
                trackingFlag = -1
            }
        }

    }

    override fun onResume() {
        super.onResume()
        if (!OpenCVLoader.initDebug()) {
            Log.d(TAG, "Internal OpenCV library not found. Using OpenCV Manager for initialization")
            OpenCVLoader.initAsync(OpenCVLoader.OPENCV_VERSION, this, mLoaderCallback)
        } else {
            Log.d(TAG, "OpenCV library found inside package. Using it!")
            mLoaderCallback.onManagerConnected(LoaderCallbackInterface.SUCCESS)
        }
    }

    override fun onPause() {
        super.onPause()
        if (mOpenCvCameraView != null) mOpenCvCameraView!!.disableView()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (mOpenCvCameraView != null) mOpenCvCameraView!!.disableView()
    }

    private val mLoaderCallback: BaseLoaderCallback = object : BaseLoaderCallback(this) {
        override fun onManagerConnected(status: Int) {
            when (status) {
                SUCCESS -> {
                    Log.i(TAG, "OpenCV loaded successfully")
                    mOpenCvCameraView!!.enableView()
                }
                else -> {
                    super.onManagerConnected(status)
                }
            }
        }
    }

    // Helper Function to map single integer to color scalar
    // https://www.particleincell.com/2014/colormap/
    fun setColor(value: Int) {
        val a = (1 - value.toDouble() / 100) / 0.2
        val X = floor(a).toInt()
        val Y = floor(255 * (a - X)).toInt()
        val newColor = doubleArrayOf(0.0, 0.0, 0.0)
        when (X) {
            0 -> {
                // r=255;g=Y;b=0;
                newColor[0] = 255.0
                newColor[1] = Y.toDouble()
            }
            1 -> {
                // r=255-Y;g=255;b=0
                newColor[0] = (255 - Y).toDouble()
                newColor[1] = 255.0
            }
            2 -> {
                // r=0;g=255;b=Y
                newColor[1] = 255.0
                newColor[2] = Y.toDouble()
            }
            3 -> {
                // r=0;g=255-Y;b=255
                newColor[1] = (255 - Y).toDouble()
                newColor[2] = 255.0
            }
            4 -> {
                // r=Y;g=0;b=255
                newColor[0] = Y.toDouble()
                newColor[2] = 255.0
            }
            5 -> {
                // r=255;g=0;b=255
                newColor[0] = 255.0
                newColor[2] = 255.0
            }
        }
        myROIColor.set(newColor)
        return
    }
    // OpenCV Camera Functionality Code
    override fun onCameraViewStarted(width: Int, height: Int) {
        mRgba = Mat(height, width, CvType.CV_8UC4)
        mGray = Mat(height, width, CvType.CV_8UC1)
        mHsv  = Mat(height,width, CvType.CV_8UC4)
        myWidth = width
        myHeight = height
    }

    override fun onCameraViewStopped() {
        mRgba!!.release()
        mGray!!.release()
    }

    override fun onCameraFrame(inputFrame: CvCameraViewFrame): Mat {
        mRgba = inputFrame.rgba()
        if(trackingFlag == 1) {
            // Timer
            val start = Core.getTickCount()
            // Grab camera frame in rgba and grayscale format
            mRgba = inputFrame.rgba()
            // Grab camera frame in gray format
            mGray = inputFrame.gray()
            // Grab camera frame in HSV format
            mHsv = mRgba?.clone()
            val hueSlider = findViewById<Slider>(R.id.hueSlider)
            val hue = hueSlider.value.toDouble().toInt()/2
            val startStopButton = findViewById<Button>(R.id.startStopButton)
            startStopButton.text = mRgba?.height().toString()
            Imgproc.cvtColor(mHsv, mHsv, Imgproc.COLOR_RGB2HSV, 3)
            val scalarLow = Scalar(hue.toDouble(), 150.0, 150.0)
            val scalarHigh = Scalar(hue.toDouble()+10, 255.0, 255.0)
            val mask = Mat()
            val masked = Mat()
            inRange(mHsv, scalarLow,scalarHigh,mask)

            bitwise_and(mRgba,mRgba,masked, mask)
            mask.release()
            Imgproc.cvtColor(masked, masked, Imgproc.COLOR_RGB2GRAY)
            Imgproc.GaussianBlur(masked,masked,Size(11.0,11.0),10.0)
            if(maskFlag == 1){return masked}


            val circles = Mat()
            Imgproc.HoughCircles(masked, circles, Imgproc.CV_HOUGH_GRADIENT, 2.0, 100.0, 100.0, 90.0)
            val circlePositionList = mutableListOf<Array<Double>>()
            var circleLengthList = mutableListOf<Array<Double>>()
            val focalLength = findViewById<EditText>(R.id.focal_length).text
            if (circles.cols() > 0) {
                for (x in 0 until min(circles.cols(), 3)) {
                    val number = findViewById<TextView>(R.id.numberFoundDisplay)
                    number.text = "No. Found: " + circles.cols().toString()
                    val realRadius = findViewById<EditText>(R.id.real_radius).text
                    val distanceDisplay = findViewById<TextView>(R.id.distanceDisplay)
                    val unit = findViewById<TextView>(R.id.units)

                    val circleVec = circles[0, x] //?: break
                    val center = Point(circleVec[0], circleVec[1])
                    val radius = circleVec[2].toInt()
                    val perceivedRadius = circleVec[2]
                    Imgproc.circle(mRgba, center, 3, Scalar(255.0, 255.0, 255.0), 5)
                    Imgproc.circle(mRgba, center, radius, Scalar(255.0, 255.0, 255.0), 2)
                    val realMeasure = (round(((realRadius.toString().toDouble()*focalLength.toString().toDouble())/perceivedRadius)*100))/100
                    
                    distanceDisplay.text = "Distance: " + realMeasure.toString() + " " + unit.text.toString()
                                              
                    val depth = realMeasure
                    circlePositionList.add(arrayOf(circleVec[0]/circleVec[2], circleVec[1]/circleVec[2],depth))
                }
            }                                              
            if(circles.cols() == 2) {
                for ((circlePosCurrent, circlePosNext) in circlePositionList.asSequence().windowed(2, 1)) {
                    val xPos = (circlePosCurrent[0] - circlePosNext[0]).pow(2)
                    val yPos = (circlePosCurrent[1] - circlePosNext[1]).pow(2)
                    val zPos = (circlePosCurrent[2] - circlePosNext[2]).pow(2)
                    val length = sqrt(xPos + yPos + zPos) / 2
                    val areaLengthDisplay = findViewById<TextView>(R.id.areaLengthDisplay)
                    areaLengthDisplay.text = "Length: " + length.toString()
                }
            }
            if(circles.cols() == 3) {
                val first = circlePositionList[0]
                val second = circlePositionList[1]   
                val third   = circlePositionList[2]
                val dotProduct = mutableListOf<Double>()
                dotProduct.add((first[1] - second[1])*(first[2] - third[2]) - (first[1] - third[1])*(first[2] - second[2]))
                dotProduct.add((first[0] - second[0])*(first[2] - third[2]) - (first[0] - third[0])*(first[2] - second[2]))
                dotProduct.add((first[0] - second[0])*(first[1] - third[1]) - (first[0] - third[0])*(first[1] - second[1]))//
                val area = ((sqrt(dotProduct[0].pow(2) + dotProduct[1].pow(2) + dotProduct[2].pow(2))))/10//*(focalLength.toString().toDouble().pow(2)))
                val areaLengthDisplay = findViewById<TextView>(R.id.areaLengthDisplay)
                areaLengthDisplay.text = "Area: " + area.toString()
            }
            circles.release()
            mask.release()
            masked.release()

            // Returned frame will be displayed on the screen



            return mRgba as Mat
        }
        return this.mRgba as Mat
    }

    companion object {
        private const val TAG = "distance.MainActivity"
    }
}